public class ShipNotFoundException extends IllegalArgumentException{
    public ShipNotFoundException(String massage){
        super(massage);
    }
}
